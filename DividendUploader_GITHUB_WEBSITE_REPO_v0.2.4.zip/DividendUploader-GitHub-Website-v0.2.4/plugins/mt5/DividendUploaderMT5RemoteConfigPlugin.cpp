// Dividend Uploader MT5 remote JSON sync plugin skeleton.
//
// This file is intentionally SDK-light so it can be copied into the real MT5
// plugin project. Wire ApplyOvernightInterestValuesFromJson() to the official
// MT5 SDK calls that update long/short overnight interest values.

#include <string>

namespace dividend_uploader_mt5 {

struct RemoteSyncSettings {
    // Wire these fields to MT5 server plugin parameters, an INI file, or a
    // local JSON file in the final SDK integration. The URL is intentionally
    // configurable and is not limited to the test domain.
    std::string base_url = "https://test.appcdn002.com";
    std::string public_base_path = "/admin-api/dividend-uploader-public";
    std::string feedback_path = "/admin-api/dividend-uploader-feedback";
    std::string metadata_file = "active-meta.json";
    std::string full_config_file = "active.json";
    std::string business_timezone = "Asia/Shanghai";
    std::string server_timezone = "UTC";
    int max_clock_drift_seconds = 120;
};

struct RemoteConfigState {
    std::string last_success_uuid;
    std::string last_error;
};

static std::string TrimTrailingSlash(std::string value) {
    while (!value.empty() && value[value.size() - 1] == '/') {
        value.erase(value.size() - 1);
    }
    return value;
}

static std::string EnsureLeadingSlash(std::string value) {
    if (value.empty()) return "/";
    return value[0] == '/' ? value : "/" + value;
}

static std::string JoinUrl(const std::string& base_url, const std::string& path, const std::string& file = "") {
    std::string url = TrimTrailingSlash(base_url) + EnsureLeadingSlash(path);
    if (!file.empty()) {
        url += "/" + file;
    }
    return url;
}

static std::string ActiveMetaUrl(const RemoteSyncSettings& settings) {
    return JoinUrl(settings.base_url, settings.public_base_path, settings.metadata_file);
}

static std::string ActiveConfigUrl(const RemoteSyncSettings& settings) {
    return JoinUrl(settings.base_url, settings.public_base_path, settings.full_config_file);
}

static std::string FeedbackUrl(const RemoteSyncSettings& settings) {
    return JoinUrl(settings.base_url, settings.feedback_path);
}

static std::string HttpGetUtf8(const std::string& url) {
    // TODO: Replace with the HTTP client approved for the MT5 plugin build.
    (void)url;
    return std::string();
}

static void ReportFeedback(
    const RemoteSyncSettings& settings,
    const std::string& uuid,
    const std::string& status,
    const std::string& mode,
    const std::string& message,
    const std::string& server_label,
    const std::string& plugin_version) {
    std::string url = FeedbackUrl(settings)
        + "?uuid=" + uuid
        + "&filename=active.json"
        + "&status=" + status
        + "&mode=" + mode
        + "&message=" + message
        + "&server=" + server_label
        + "&plugin_version=" + plugin_version;
    (void)HttpGetUtf8(url);
}

static bool ExtractJsonString(const std::string& json, const std::string& key, std::string* value) {
    const std::string marker = "\"" + key + "\"";
    const size_t key_pos = json.find(marker);
    if (key_pos == std::string::npos) return false;
    const size_t colon = json.find(':', key_pos + marker.size());
    const size_t first_quote = json.find('"', colon + 1);
    const size_t second_quote = json.find('"', first_quote + 1);
    if (colon == std::string::npos || first_quote == std::string::npos || second_quote == std::string::npos) return false;
    *value = json.substr(first_quote + 1, second_quote - first_quote - 1);
    return true;
}

static bool ApplyOvernightInterestValuesFromJson(const std::string& active_json, std::string* error) {
    // TODO:
    // 1. Parse website JSON.
    // 2. Read current MT5 mode and triple day as read-only context.
    // 3. Update only longInterestValue and shortInterestValue.
    // 4. Do not create Balance/Deal operations.
    (void)active_json;
    (void)error;
    return true;
}

static bool IsTimeSyncAcceptable(const std::string& updated_at_utc, const RemoteSyncSettings& settings, std::string* warning) {
    // The website publishes updated_at and effectiveFromUtc as UTC ISO 8601.
    // In the SDK integration, compare those UTC values with server UTC time
    // and reject/flag drift beyond settings.max_clock_drift_seconds.
    (void)updated_at_utc;
    (void)settings;
    (void)warning;
    return true;
}

static bool PollAndApply(RemoteConfigState* state, const std::string& server_label, const RemoteSyncSettings& settings) {
    std::string meta = HttpGetUtf8(ActiveMetaUrl(settings));
    std::string remote_uuid;
    std::string remote_updated_at;
    ExtractJsonString(meta, "updated_at", &remote_updated_at);
    if (!ExtractJsonString(meta, "uuid", &remote_uuid) || remote_uuid.empty()) {
        state->last_error = "Failed to read active UUID";
        ReportFeedback(settings, state->last_success_uuid, "error", "connect-check", "Failed%20to%20read%20active%20UUID", server_label, "0.2.3-mt5");
        return false;
    }

    std::string time_warning;
    if (!IsTimeSyncAcceptable(remote_updated_at, settings, &time_warning)) {
        state->last_error = time_warning;
        ReportFeedback(settings, remote_uuid, "error", "connect-check", "Time%20sync%20check%20failed", server_label, "0.2.3-mt5");
        return false;
    }

    if (remote_uuid == state->last_success_uuid) {
        ReportFeedback(settings, remote_uuid, "unchanged", "connect-check", "UUID%20unchanged", server_label, "0.2.3-mt5");
        return true;
    }

    std::string active_json = HttpGetUtf8(ActiveConfigUrl(settings));
    std::string full_uuid;
    if (!ExtractJsonString(active_json, "uuid", &full_uuid) || full_uuid != remote_uuid) {
        state->last_error = "Full config UUID mismatch";
        ReportFeedback(settings, remote_uuid, "error", "full-read", "Full%20config%20UUID%20mismatch", server_label, "0.2.3-mt5");
        return false;
    }

    std::string apply_error;
    if (!ApplyOvernightInterestValuesFromJson(active_json, &apply_error)) {
        ReportFeedback(settings, remote_uuid, "failed", "full-read", "Apply%20failed", server_label, "0.2.3-mt5");
        return false;
    }

    state->last_success_uuid = remote_uuid;
    ReportFeedback(settings, remote_uuid, "read", "full-read", "Config%20loaded%20successfully", server_label, "0.2.3-mt5");
    return true;
}

static bool PollAndApply(RemoteConfigState* state, const std::string& server_label) {
    return PollAndApply(state, server_label, RemoteSyncSettings{});
}

}  // namespace dividend_uploader_mt5
